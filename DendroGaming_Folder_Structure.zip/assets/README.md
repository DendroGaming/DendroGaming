# Assets

This folder is for assets related files.