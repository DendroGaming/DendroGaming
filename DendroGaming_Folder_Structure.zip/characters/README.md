# Characters

This folder is for characters related files.